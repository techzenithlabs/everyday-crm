import api from "../api";
import { AxiosError } from "axios";

interface RegisterPayload {
  name: string;
  email: string;
  password: string;
  role_id?: number; // optional if you're assigning on backend
}

// === REGISTER ===
export const registerUser = async (form: RegisterPayload) => {
  try {
    await api.get("/sanctum/csrf-cookie"); // CSRF cookie
    const response = await api.post("/register", form);
    return response.data;
  } catch (error) {
    const err = error as AxiosError<{ message: string }>;
    throw err.response?.data || { message: "Registration failed" };
  }
};

// === LOGIN ===
export const loginUser = async (email: string, password: string) => {
  try {
    await api.get("/sanctum/csrf-cookie"); // CSRF cookie
    const response = await api.post("/login", { email, password });
    return response.data;
  } catch (error) {
    const err = error as AxiosError<{ message: string }>;
    throw err.response?.data || { message: "Login failed" };
  }
};

// === LOGOUT ===
export const logoutUser = async (token: string) => {
  await api.get("/sanctum/csrf-cookie"); // Optional but safe
  return await api.post(
    "/logout",
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
};

// === GET PROFILE ===
export const getProfile = async (token: string) => {
  try {
    const response = await api.get("/profile", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    const err = error as AxiosError<{ message: string }>;
    throw err.response?.data || { message: "Failed to fetch profile" };
  }
};

// === UPDATE PROFILE ===
export const updateProfile = async (token: string, data: any) => {
  const response = await api.put("/profile/update", data, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
};

// === FORGOT PASSWORD ===
export const forgotPassword = async (email: string) => {
  try {
    await api.get("/sanctum/csrf-cookie"); // Safe before POST
    const response = await api.post("/forgot-password", { email });
    return response.data;
  } catch (error) {
    const err = error as AxiosError<{ message: string }>;
    throw err.response?.data || {
      message: "Failed to send reset password link.",
    };
  }
};

// === RESET PASSWORD ===
export const resetPassword = async (payload: {
  token: string;
  email: string;
  password: string;
  password_confirmation: string;
}) => {
  try {
    await api.get("/sanctum/csrf-cookie"); // Safe before POST
    const response = await api.post("/reset-password", payload);
    return response.data;
  } catch (error) {
    const err = error as AxiosError<{ message: string }>;
    throw err.response?.data || { message: "Reset password failed" };
  }
};
